import { Outlet } from 'react-router-dom';
import { SidebarProvider } from "@finlight/ui";
import { AppSidebar } from "./AppSidebar";
import { AppHeader } from "./AppHeader";

export default function Layout() {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <AppHeader />
          <main className="flex-1 overflow-y-auto p-4 md:p-8 animate-fade-in">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
